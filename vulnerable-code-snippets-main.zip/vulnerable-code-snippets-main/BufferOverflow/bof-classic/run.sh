#!/bin/bash
docker compose run --service-ports gcc
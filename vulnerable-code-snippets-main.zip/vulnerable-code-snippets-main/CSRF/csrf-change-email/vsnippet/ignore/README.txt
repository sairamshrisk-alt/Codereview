All files in the "Ignore" folder are not part of the Vulnerable Snippets challenge.
They are all here to provide the necessary resources for the challenge to work properly.

Happy hacking! / YesWeHack

<?php
echo '
<h1>CONTACT</h1>
<p>I\'m to busy to be contacted</p>
';
?>

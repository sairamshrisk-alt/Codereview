<?php
echo '
<h1>ABOUT</h1>
<p>What about it?</p>
';
?>

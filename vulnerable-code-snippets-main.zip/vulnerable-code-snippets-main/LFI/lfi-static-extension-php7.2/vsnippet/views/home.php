<?php
echo '
<h1>HOME</h1>
<p>Home sweet home</p>
';
?>
